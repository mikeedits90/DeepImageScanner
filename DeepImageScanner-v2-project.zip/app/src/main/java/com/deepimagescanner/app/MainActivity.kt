package com.deepimagescanner.app

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deepimagescanner.app.databinding.ActivityMainBinding
import com.deepimagescanner.app.databinding.ItemImageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class ImageItem(
    val key: String,
    val uri: Uri?,
    val name: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val location: String,
    val category: String,
    val file: File? = null
)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val items = mutableListOf<ImageItem>()
    private lateinit var adapter: ImageAdapter

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { ensureAndScanAfterPermission() }

    private val allFilesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { updateDeepScanButton(); ensurePermissionAndScan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adapter = ImageAdapter(items)
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter
        binding.scanButton.setOnClickListener { ensurePermissionAndScan() }
        binding.deepScanButton.setOnClickListener { requestAllFilesAccess() }
        updateDeepScanButton()
        ensurePermissionAndScan()
    }

    override fun onResume() {
        super.onResume()
        updateDeepScanButton()
    }

    private fun hasImagePermission(): Boolean = when {
        Build.VERSION.SDK_INT >= 33 ->
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            (Build.VERSION.SDK_INT >= 34 && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED)
        else -> ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun ensurePermissionAndScan() {
        if (hasImagePermission()) scan() else {
            val perms = if (Build.VERSION.SDK_INT >= 34)
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            else if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissionLauncher.launch(perms)
        }
    }

    private fun ensureAndScanAfterPermission() {
        if (hasImagePermission() || hasAllFilesAccess()) scan()
        else binding.status.text = "No image access granted. Tap Scan images and allow photos, or enable Deep Scan."
    }

    private fun hasAllFilesAccess() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30) { ensurePermissionAndScan(); return }
        if (Environment.isExternalStorageManager()) { scan(); return }
        AlertDialog.Builder(this)
            .setTitle("Enable Deep Scan")
            .setMessage("Android's All files access lets this app inspect shared storage for image files that may not appear in the normal photo library, including accessible thumbnails and caches. It still cannot read other apps' protected private data.")
            .setPositiveButton("Open settings") { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName"))
                allFilesLauncher.launch(intent)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun updateDeepScanButton() {
        binding.deepScanButton.text = if (hasAllFilesAccess()) "DEEP SCAN ENABLED" else "ENABLE DEEP SCAN (ALL FILES)"
    }

    private fun scan() {
        binding.progress.visibility = View.VISIBLE
        binding.scanButton.isEnabled = false
        binding.status.text = if (hasAllFilesAccess()) "Deep scanning accessible shared storage…" else "Scanning Android's image library…"
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) {
                val map = LinkedHashMap<String, ImageItem>()
                scanMediaStore(map)
                if (hasAllFilesAccess()) scanFiles(map)
                map.values.sortedBy { it.name.lowercase(Locale.US) }
            }
            items.clear(); items.addAll(found); adapter.notifyDataSetChanged()
            binding.count.text = "${items.size} images"
            val thumbs = items.count { it.category != "Image" }
            binding.status.text = if (items.isEmpty())
                "No accessible images found. Check Android photo permission or enable Deep Scan."
            else "Scan complete • ${items.size} images • $thumbs thumbnail/cache-like"
            binding.progress.visibility = View.GONE
            binding.scanButton.isEnabled = true
        }
    }

    private fun scanMediaStore(out: MutableMap<String, ImageItem>) {
        val projection = mutableListOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        ).apply { if (Build.VERSION.SDK_INT >= 29) add(MediaStore.Images.Media.RELATIVE_PATH) }.toTypedArray()
        contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null,
            "${MediaStore.Images.Media.DATE_MODIFIED} DESC")?.use { c ->
            val idI = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameI = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeI = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val wI = c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val hI = c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            val pathI = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH) else -1
            while (c.moveToNext()) {
                val id = c.getLong(idI)
                val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                val path = if (pathI >= 0) c.getString(pathI) ?: "MediaStore" else "MediaStore"
                val name = c.getString(nameI) ?: "(unnamed)"
                out["media:$id"] = ImageItem("media:$id", uri, name, c.getLong(sizeI), c.getInt(wI), c.getInt(hI), path, classify(name, path))
            }
        }
    }

    private fun scanFiles(out: MutableMap<String, ImageItem>) {
        val root = Environment.getExternalStorageDirectory()
        val extensions = setOf("jpg","jpeg","png","webp","gif","bmp","heic","heif","avif")
        root.walkTopDown().onEnter { dir ->
            // Android may still block protected directories; skip unreadable folders cleanly.
            dir.canRead()
        }.forEach { f ->
            try {
                if (!f.isFile || f.extension.lowercase(Locale.US) !in extensions || !f.canRead()) return@forEach
                val path = f.absolutePath
                val key = "file:$path"
                if (out.values.any { it.name == f.name && it.size == f.length() && it.location.endsWith(f.parentFile?.name ?: "__") }) return@forEach
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, opts)
                out[key] = ImageItem(key, Uri.fromFile(f), f.name, f.length(), opts.outWidth.coerceAtLeast(0), opts.outHeight.coerceAtLeast(0), path, classify(f.name, path), f)
            } catch (_: Exception) { }
        }
    }

    private fun classify(name: String, path: String): String {
        val s = "$name $path".lowercase(Locale.US)
        return when {
            "thumbnail" in s || "/.thumbnails" in s || "thumb" in s -> "Thumbnail"
            "cache" in s || "/.cache" in s -> "Cache-like"
            else -> "Image"
        }
    }

    private fun humanSize(bytes: Long): String = when {
        bytes >= 1024L*1024L -> String.format(Locale.US, "%.1f MB", bytes/(1024.0*1024.0))
        bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes/1024.0)
        else -> "$bytes B"
    }

    inner class ImageAdapter(private val data: List<ImageItem>) : RecyclerView.Adapter<ImageAdapter.Holder>() {
        inner class Holder(val b: ItemImageBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount() = data.size
        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = data[position]
            holder.b.name.text = item.name
            holder.b.details.text = "${item.category} • ${item.width}×${item.height} • ${humanSize(item.size)}\n${item.location}"
            holder.b.thumb.setImageDrawable(null)
            try { if (item.file != null) holder.b.thumb.setImageURI(Uri.fromFile(item.file)) else holder.b.thumb.setImageURI(item.uri) } catch (_: Exception) { }
            holder.itemView.setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle(item.name)
                    .setMessage("Type: ${item.category}\nDimensions: ${item.width}×${item.height}\nSize: ${humanSize(item.size)}\n\nLocation:\n${item.location}")
                    .setPositiveButton("OK", null).show()
            }
        }
    }
}
