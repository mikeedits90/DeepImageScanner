# DeepImageScanner

Android image inventory/scanner.

## What v1 does
- Requests Android image access.
- Scans images exposed through Android MediaStore.
- Shows filename, dimensions, size, relative folder, and thumbnail.
- Does not delete anything.

## Important Android limitation
Modern Android intentionally prevents ordinary apps from silently reading every private file,
other apps' private caches, and all hidden thumbnail databases. This app stays within Android's
supported storage/security model rather than pretending it can bypass those protections.

## Build
The included GitHub Actions workflow builds a debug APK automatically on pushes to `main`.
