# DeepSight / Deep Image Scanner v5

Deep scan build with honest artifact classification, exact-content duplicate elimination, Interesting filter, full-size safe viewer, blocked-path reporting, and deep scan diagnostics.

Important Android limitation: protected app-private storage such as Android/data and Android/obb cannot be bypassed by a normal non-root app on current Android. DeepSight reports those boundaries rather than claiming access it does not have.
