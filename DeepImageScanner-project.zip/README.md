# DeepSight — Deep Image Scanner

DeepImageScanner V4 / DeepSight development build.

## What changed
- Safe sampled thumbnails prevent huge images from crashing Android Canvas.
- Deep Scan recursively searches accessible shared storage.
- Detects JPEG/PNG/GIF/WebP/BMP and HEIC/HEIF/AVIF-like files by file signature, even with missing/misleading extensions.
- Classifies hidden, thumbnail, cache, temporary, app-media and filesystem findings.
- Professional dark DeepSight dashboard and discovery counters.
- Android private app storage remains protected without root; the app reports only data Android allows it to read.

GitHub Actions builds `app-debug.apk` as the `DeepImageScanner-debug-apk` artifact.
