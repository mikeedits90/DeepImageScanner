package com.deepimagescanner.app

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class CrashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val details = intent.getStringExtra("crash")
            ?: runCatching { File(filesDir, "last_crash.txt").readText() }.getOrDefault("No crash details available.")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(TextView(context).apply { text = "Deep Image Scanner hit an error. The crash details are shown below so we can fix it."; textSize = 18f })
            addView(Button(context).apply { text = "CLOSE"; setOnClickListener { finish() } })
            addView(TextView(context).apply { text = details; setTextIsSelectable(true); textSize = 12f })
        }
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
