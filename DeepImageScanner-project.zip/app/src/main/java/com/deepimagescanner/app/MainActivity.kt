package com.deepimagescanner.app

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deepimagescanner.app.databinding.ActivityMainBinding
import com.deepimagescanner.app.databinding.ItemImageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale

data class ImageItem(
    val key: String, val uri: Uri?, val name: String, val size: Long,
    val width: Int, val height: Int, val location: String, val category: String,
    val detectedType: String, val file: File? = null, val contentHash: String? = null
)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val allItems = mutableListOf<ImageItem>()
    private val items = mutableListOf<ImageItem>()
    private lateinit var adapter: ImageAdapter
    private var activeFilter = "All"
    private var lastReport = ScanReport()

    data class ScanReport(var dirsChecked:Int=0,var dirsDenied:Int=0,var filesInspected:Long=0,var signatures:Long=0,var mediaStore:Int=0,var deepUnique:Int=0,var galleryArtifacts:Int=0,var exactDuplicates:Int=0,var unknown:Int=0,val denied:MutableList<String> = mutableListOf())

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ensureAndScanAfterPermission() }
    private val allFilesLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { updateDeepScanButton(); ensurePermissionAndScan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        adapter = ImageAdapter(items)
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter
        binding.scanButton.setOnClickListener { ensurePermissionAndScan() }
        binding.deepScanButton.setOnClickListener { requestAllFilesAccess() }
        binding.reportButton.setOnClickListener { showScanReport() }
        setupFilters()
        updateDeepScanButton()
        binding.status.text = "Ready for discovery"
    }

    override fun onResume() { super.onResume(); if (::binding.isInitialized) updateDeepScanButton() }

    private fun hasImagePermission(): Boolean = when {
        Build.VERSION.SDK_INT >= 33 -> ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            (Build.VERSION.SDK_INT >= 34 && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED)
        else -> ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun ensurePermissionAndScan() {
        if (hasImagePermission() || hasAllFilesAccess()) scan() else {
            val perms = if (Build.VERSION.SDK_INT >= 34) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            else if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissionLauncher.launch(perms)
        }
    }

    private fun ensureAndScanAfterPermission() {
        if (hasImagePermission() || hasAllFilesAccess()) scan() else binding.status.text = "Image access not granted"
    }

    private fun hasAllFilesAccess() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) { scan(); return }
        AlertDialog.Builder(this).setTitle("Enable Deep Scan")
            .setMessage("Deep Scan searches accessible shared storage beyond the normal gallery, including hidden files, thumbnails, caches, temp files and image data with misleading or missing extensions. Android still protects other apps' private internal storage unless the device is rooted.")
            .setPositiveButton("Open settings") { _, _ ->
                try { allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun updateDeepScanButton() {
        binding.deepScanButton.text = if (hasAllFilesAccess()) "RUN DEEP SCAN" else "UNLOCK DEEP SCAN"
        binding.accessBadge.text = if (hasAllFilesAccess()) "DEEP ACCESS ON" else "STANDARD ACCESS"
    }

    private fun scan() {
        binding.progress.visibility = View.VISIBLE
        binding.scanButton.isEnabled = false; binding.deepScanButton.isEnabled = false
        binding.status.text = if (hasAllFilesAccess()) "Deep-diving through accessible storage…" else "Scanning Android media library…"
        lifecycleScope.launch {
            val pair = withContext(Dispatchers.IO) {
                val report=ScanReport(); val map=LinkedHashMap<String,ImageItem>()
                runCatching { scanMediaStore(map,report) }
                if(hasAllFilesAccess()) runCatching { scanFilesDeep(map,report) }
                postProcessDiscoveries(map, report)
                report.deepUnique=map.values.count { isInteresting(it) }
                Pair(map.values.sortedWith(compareBy<ImageItem> { it.category == "Gallery" }.thenByDescending { it.size }),report)
            }
            allItems.clear(); allItems.addAll(pair.first); lastReport=pair.second; applyFilter(activeFilter)
            val deep=allItems.count { isInteresting(it) }
            val hidden=allItems.count { it.category == "Hidden" }
            val cache=allItems.count { it.category == "Cache" }
            binding.count.text="${allItems.size}"; binding.deepCount.text="$deep"; binding.hiddenCount.text="$hidden"; binding.cacheCount.text="$cache"
            binding.status.text=if(allItems.isEmpty()) "Nothing accessible was found" else "Scan complete • $deep unique findings beyond gallery • ${lastReport.dirsDenied} blocked folders"
            binding.progress.visibility=View.GONE; binding.scanButton.isEnabled=true; binding.deepScanButton.isEnabled=true
        }
    }

    private fun showScanReport() {
        val r=lastReport
        val blocked=if(r.denied.isEmpty()) "None recorded" else r.denied.take(12).joinToString("\n")
        AlertDialog.Builder(this).setTitle("Deep Scan Report")
            .setMessage("Directories checked: ${r.dirsChecked}\nDirectories blocked: ${r.dirsDenied}\nFiles inspected: ${r.filesInspected}\nImage signatures detected: ${r.signatures}\nMediaStore images: ${r.mediaStore}\nInteresting non-gallery findings: ${r.deepUnique}\nGallery artifacts: ${r.galleryArtifacts}\nExact duplicates removed: ${r.exactDuplicates}\nUnknown / unusual: ${r.unknown}\n\nBlocked / protected paths (first 12):\n$blocked\n\nAndroid intentionally protects other apps' private internal data. DeepSight reports those boundaries instead of pretending they were scanned.")
            .setPositiveButton("OK",null).show()
    }

    private fun scanMediaStore(out: MutableMap<String, ImageItem>, report: ScanReport) {
        val projection = mutableListOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.MIME_TYPE)
            .apply { if (Build.VERSION.SDK_INT >= 29) add(MediaStore.Images.Media.RELATIVE_PATH) }.toTypedArray()
        contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Images.Media.DATE_MODIFIED} DESC")?.use { c ->
            val idI=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID); val nameI=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeI=c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE); val wI=c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val hI=c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT); val mimeI=c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
            val pathI=if(Build.VERSION.SDK_INT>=29)c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH) else -1
            while(c.moveToNext()) {
                val id=c.getLong(idI); val uri=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,id)
                val path=if(pathI>=0)c.getString(pathI)?:"MediaStore" else "MediaStore"; val name=c.getString(nameI)?:"(unnamed)"
                out["media:$id"] = ImageItem("media:$id",uri,name,c.getLong(sizeI),c.getInt(wI),c.getInt(hI),path,"Gallery",c.getString(mimeI)?:"image",null); report.mediaStore++
            }
        }
    }

    private fun scanFilesDeep(out: MutableMap<String, ImageItem>, report: ScanReport) {
        val knownExtensions=setOf("jpg","jpeg","png","webp","gif","bmp","heic","heif","avif","ico","tif","tiff","dng","jfif")
                val roots=linkedSetOf<File>()
        roots.add(Environment.getExternalStorageDirectory())
        getExternalFilesDirs(null).filterNotNull().forEach { d ->
            val marker="/Android/data/"; val i=d.absolutePath.indexOf(marker)
            if(i>0) roots.add(File(d.absolutePath.substring(0,i)))
        }
        val visited=hashSetOf<String>()
        fun walk(dir:File) {
            val canonical=runCatching{dir.canonicalPath}.getOrElse{dir.absolutePath}
            if(!visited.add(canonical)) return
            report.dirsChecked++
            val children=try { dir.listFiles() } catch(_:Throwable){ null }
            if(children==null) { report.dirsDenied++; if(report.denied.size<50)report.denied.add(dir.absolutePath); return }
            for(f in children) {
                try {
                    if(f.isDirectory) { walk(f); continue }
                    if(!f.isFile || f.length()<=0L) continue
                    report.filesInspected++
                    val ext=f.extension.lowercase(Locale.US)
                    val signature=detectImageSignature(f)
                    if(signature!=null) report.signatures++
                    if(ext !in knownExtensions && signature==null) continue
                    val opts=BitmapFactory.Options().apply{inJustDecodeBounds=true}; BitmapFactory.decodeFile(f.absolutePath,opts)
                    val type=signature ?: ext.uppercase(Locale.US).ifBlank{"IMAGE"}
                    val category=classifyDeep(f)
                    val hash=if(f.length() <= 64L*1024L*1024L) sha256(f) else null
                    out["file:${f.absolutePath}"]=ImageItem("file:${f.absolutePath}",Uri.fromFile(f),f.name,f.length(),opts.outWidth.coerceAtLeast(0),opts.outHeight.coerceAtLeast(0),f.absolutePath,category,type,f,hash)
                } catch(_:SecurityException) { report.dirsDenied++; if(report.denied.size<50)report.denied.add(f.absolutePath) }
                catch(_:Throwable) { }
            }
        }
        roots.filter{it.exists()}.forEach{walk(it)}
    }

    private fun isDeepLocation(path:String):Boolean {
        val s=path.lowercase(Locale.US)
        return "/." in s || "thumb" in s || "cache" in s || "temp" in s || "tmp" in s || "/android/" in s
    }

    private fun classifyDeep(f:File):String {
        val s=f.absolutePath.lowercase(Locale.US)
        return when {
            "thumbnail" in s || "thumb" in s -> "Thumbnail"
            "cache" in s -> "Cache"
            "temp" in s || "/tmp" in s -> "Temporary"
            "/android/media/" in s -> "App media"
            f.name.startsWith(".") || s.split('/').any { it.startsWith(".") && it.length > 1 } || hasNomediaAncestor(f) -> "Hidden"
            f.extension.isBlank() -> "Unknown"
            else -> "File system"
        }
    }

    private fun hasNomediaAncestor(f: File): Boolean {
        val root = Environment.getExternalStorageDirectory().absolutePath
        var dir = f.parentFile
        while (dir != null && dir.absolutePath.startsWith(root)) {
            if (File(dir, ".nomedia").exists()) return true
            if (dir.absolutePath == root) break
            dir = dir.parentFile
        }
        return false
    }

    private fun setupFilters() {
        val filters=listOf("All","Interesting","Gallery","Gallery artifact","Hidden","Thumbnail","Cache","Temporary","App media","File system","Unknown")
        filters.forEach { label ->
            val button=Button(this).apply {
                text=label.uppercase(Locale.US); textSize=10f; isAllCaps=false
                setTextColor(android.graphics.Color.parseColor("#F4F8FB"))
                backgroundTintList=android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#18232C"))
                setPadding(22,0,22,0)
                setOnClickListener { applyFilter(label) }
            }
            binding.filterBar.addView(button, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 44.dp()))
        }
    }

    private fun Int.dp():Int=(this*resources.displayMetrics.density).toInt()

    private fun applyFilter(filter:String) {
        activeFilter=filter
        val filtered=when(filter) {
            "All" -> allItems
            "Interesting" -> allItems.filter { isInteresting(it) }
            else -> allItems.filter { it.category == filter }
        }
        items.clear(); items.addAll(filtered); if(::adapter.isInitialized) adapter.notifyDataSetChanged()
        if(::binding.isInitialized) binding.resultsLabel.text="${filter.uppercase(Locale.US)} • ${items.size} RESULTS"
    }


    private fun isInteresting(item: ImageItem): Boolean = item.category !in setOf("Gallery", "Gallery artifact")

    private fun sha256(file: File): String? = runCatching {
        val md=MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf=ByteArray(64*1024)
            while(true){ val n=input.read(buf); if(n<=0) break; md.update(buf,0,n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    private fun postProcessDiscoveries(map: LinkedHashMap<String, ImageItem>, report: ScanReport) {
        // Exact file-content duplicates are collapsed before the UI counts anything as a deep finding.
        val seenHashes=hashSetOf<String>()
        val remove=mutableListOf<String>()
        map.values.filter { it.category != "Gallery" && it.contentHash != null }.forEach { item ->
            if(!seenHashes.add(item.contentHash!!)) { remove.add(item.key); report.exactDuplicates++ }
        }
        remove.forEach { map.remove(it) }

        // Thumbnails/previews in conventional thumbnail trees are gallery artifacts, not novel evidence.
        // This deliberately favors honest counts over calling resized gallery previews "deep".
        val replacements=mutableListOf<Pair<String,ImageItem>>()
        map.values.forEach { item ->
            if(item.category=="Thumbnail") {
                val p=item.location.lowercase(Locale.US)
                if("/pictures/.thumbnails/" in p || "/dcim/.thumbnails/" in p || "/.thumbnails/" in p) {
                    replacements += item.key to item.copy(category="Gallery artifact")
                    report.galleryArtifacts++
                }
            }
        }
        replacements.forEach { (k,v) -> map[k]=v }
        report.unknown=map.values.count { it.category=="Unknown" }
    }
    private fun detectImageSignature(f:File):String? {
        if(f.length()<4) return null
        val b=ByteArray(16); val n=FileInputStream(f).use { it.read(b) }; if(n<4)return null
        fun u(i:Int)=b[i].toInt() and 0xff
        return when {
            u(0)==0xFF && u(1)==0xD8 && u(2)==0xFF -> "JPEG"
            u(0)==0x89 && b.copyOfRange(1,4).toString(Charsets.ISO_8859_1)=="PNG" -> "PNG"
            b.copyOfRange(0,3).toString(Charsets.US_ASCII)=="GIF" -> "GIF"
            b.copyOfRange(0,4).toString(Charsets.US_ASCII)=="RIFF" && n>=12 && b.copyOfRange(8,12).toString(Charsets.US_ASCII)=="WEBP" -> "WEBP"
            u(0)==0x42 && u(1)==0x4D -> "BMP"
            n>=12 && b.copyOfRange(4,8).toString(Charsets.US_ASCII)=="ftyp" -> {
                val brand=b.copyOfRange(8,12).toString(Charsets.US_ASCII).lowercase(Locale.US)
                if(brand.contains("heic")||brand.contains("heif")||brand.contains("avif")||brand.contains("mif1")) brand.uppercase(Locale.US) else null
            }
            else -> null
        }
    }

    private fun humanSize(bytes:Long)=when { bytes>=1024L*1024L->String.format(Locale.US,"%.1f MB",bytes/(1024.0*1024)); bytes>=1024->String.format(Locale.US,"%.1f KB",bytes/1024.0); else->"$bytes B" }

    private fun safeDecodeFile(file:File,target:Int=220):Bitmap? {
        val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
        BitmapFactory.decodeFile(file.absolutePath,bounds)
        if(bounds.outWidth<=0||bounds.outHeight<=0)return null
        var sample=1
        while(bounds.outWidth/sample>target*2 || bounds.outHeight/sample>target*2) sample*=2
        return BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply { inSampleSize=sample; inPreferredConfig=Bitmap.Config.RGB_565 })
    }

    inner class ImageAdapter(private val data:List<ImageItem>):RecyclerView.Adapter<ImageAdapter.Holder>() {
        inner class Holder(val b:ItemImageBinding):RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent:ViewGroup,viewType:Int)=Holder(ItemImageBinding.inflate(LayoutInflater.from(parent.context),parent,false))
        override fun getItemCount()=data.size
        override fun onBindViewHolder(holder:Holder,position:Int) {
            val item=data[position]; holder.b.name.text=item.name
            holder.b.category.text=item.category.uppercase(Locale.US)
            holder.b.details.text="${item.detectedType} • ${item.width}×${item.height} • ${humanSize(item.size)}\n${item.location}"
            holder.b.thumb.setImageResource(android.R.drawable.ic_menu_gallery); holder.b.thumb.tag=item.key
            lifecycleScope.launch {
                val bitmap=withContext(Dispatchers.IO) { try { if(item.file!=null) safeDecodeFile(item.file) else if(Build.VERSION.SDK_INT>=29 && item.uri!=null) contentResolver.loadThumbnail(item.uri,Size(220,220),null) else null } catch(_:Throwable){null} }
                if(holder.b.thumb.tag==item.key && bitmap!=null) holder.b.thumb.setImageBitmap(bitmap)
            }
            holder.itemView.setOnClickListener {
                val meta="${item.category} • ${item.detectedType} • ${item.width}×${item.height} • ${humanSize(item.size)}\n${item.location}"
                startActivity(Intent(this@MainActivity,ViewerActivity::class.java).apply {
                    putExtra("name",item.name); putExtra("meta",meta)
                    item.file?.let { putExtra("path",it.absolutePath) }
                    if(item.file==null) item.uri?.let { putExtra("uri",it.toString()) }
                })
            }
        }
        override fun onViewRecycled(holder:Holder) { holder.b.thumb.tag=null; holder.b.thumb.setImageDrawable(null); super.onViewRecycled(holder) }
    }
}
