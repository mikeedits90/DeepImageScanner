package com.deepimagescanner.app

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deepimagescanner.app.databinding.ActivityMainBinding
import com.deepimagescanner.app.databinding.ItemImageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale

data class ImageItem(
    val key: String, val uri: Uri?, val name: String, val size: Long,
    val width: Int, val height: Int, val location: String, val category: String,
    val detectedType: String, val file: File? = null
)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val allItems = mutableListOf<ImageItem>()
    private val items = mutableListOf<ImageItem>()
    private lateinit var adapter: ImageAdapter
    private var activeFilter = "All"

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ensureAndScanAfterPermission() }
    private val allFilesLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { updateDeepScanButton(); ensurePermissionAndScan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        adapter = ImageAdapter(items)
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter
        binding.scanButton.setOnClickListener { ensurePermissionAndScan() }
        binding.deepScanButton.setOnClickListener { requestAllFilesAccess() }
        setupFilters()
        updateDeepScanButton()
        binding.status.text = "Ready for discovery"
    }

    override fun onResume() { super.onResume(); if (::binding.isInitialized) updateDeepScanButton() }

    private fun hasImagePermission(): Boolean = when {
        Build.VERSION.SDK_INT >= 33 -> ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            (Build.VERSION.SDK_INT >= 34 && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED)
        else -> ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun ensurePermissionAndScan() {
        if (hasImagePermission() || hasAllFilesAccess()) scan() else {
            val perms = if (Build.VERSION.SDK_INT >= 34) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            else if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissionLauncher.launch(perms)
        }
    }

    private fun ensureAndScanAfterPermission() {
        if (hasImagePermission() || hasAllFilesAccess()) scan() else binding.status.text = "Image access not granted"
    }

    private fun hasAllFilesAccess() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) { scan(); return }
        AlertDialog.Builder(this).setTitle("Enable Deep Scan")
            .setMessage("Deep Scan searches accessible shared storage beyond the normal gallery, including hidden files, thumbnails, caches, temp files and image data with misleading or missing extensions. Android still protects other apps' private internal storage unless the device is rooted.")
            .setPositiveButton("Open settings") { _, _ ->
                try { allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun updateDeepScanButton() {
        binding.deepScanButton.text = if (hasAllFilesAccess()) "RUN DEEP SCAN" else "UNLOCK DEEP SCAN"
        binding.accessBadge.text = if (hasAllFilesAccess()) "DEEP ACCESS ON" else "STANDARD ACCESS"
    }

    private fun scan() {
        binding.progress.visibility = View.VISIBLE
        binding.scanButton.isEnabled = false; binding.deepScanButton.isEnabled = false
        binding.status.text = if (hasAllFilesAccess()) "Deep-diving through accessible storage…" else "Scanning Android media library…"
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) {
                val map = LinkedHashMap<String, ImageItem>()
                runCatching { scanMediaStore(map) }
                if (hasAllFilesAccess()) runCatching { scanFilesDeep(map) }
                map.values.sortedWith(compareBy<ImageItem> { it.category == "Gallery" }.thenByDescending { it.size })
            }
            allItems.clear(); allItems.addAll(found); applyFilter(activeFilter)
            val deep = allItems.count { it.category != "Gallery" }
            val hidden = allItems.count { it.category == "Hidden" }
            val thumbs = allItems.count { it.category == "Thumbnail" || it.category == "Cache" }
            binding.count.text = "${allItems.size}"
            binding.deepCount.text = "$deep"
            binding.hiddenCount.text = "$hidden"
            binding.cacheCount.text = "$thumbs"
            binding.status.text = if (allItems.isEmpty()) "Nothing accessible was found" else "Scan complete • $deep findings beyond normal gallery"
            binding.progress.visibility = View.GONE
            binding.scanButton.isEnabled = true; binding.deepScanButton.isEnabled = true
        }
    }

    private fun scanMediaStore(out: MutableMap<String, ImageItem>) {
        val projection = mutableListOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.MIME_TYPE)
            .apply { if (Build.VERSION.SDK_INT >= 29) add(MediaStore.Images.Media.RELATIVE_PATH) }.toTypedArray()
        contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Images.Media.DATE_MODIFIED} DESC")?.use { c ->
            val idI=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID); val nameI=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeI=c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE); val wI=c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val hI=c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT); val mimeI=c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
            val pathI=if(Build.VERSION.SDK_INT>=29)c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH) else -1
            while(c.moveToNext()) {
                val id=c.getLong(idI); val uri=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,id)
                val path=if(pathI>=0)c.getString(pathI)?:"MediaStore" else "MediaStore"; val name=c.getString(nameI)?:"(unnamed)"
                out["media:$id"] = ImageItem("media:$id",uri,name,c.getLong(sizeI),c.getInt(wI),c.getInt(hI),path,"Gallery",c.getString(mimeI)?:"image",null)
            }
        }
    }

    private fun scanFilesDeep(out: MutableMap<String, ImageItem>) {
        val root=Environment.getExternalStorageDirectory()
        val knownExtensions=setOf("jpg","jpeg","png","webp","gif","bmp","heic","heif","avif","ico","tif","tiff","dng")
        val mediaFingerprints=out.values.map { "${it.name.lowercase(Locale.US)}:${it.size}" }.toHashSet()
        root.walkTopDown().onEnter { it.canRead() }.forEach { f ->
            try {
                if(!f.isFile || !f.canRead() || f.length()<=0L) return@forEach
                val ext=f.extension.lowercase(Locale.US)
                val signature=detectImageSignature(f)
                if(ext !in knownExtensions && signature==null) return@forEach
                val fingerprint="${f.name.lowercase(Locale.US)}:${f.length()}"
                if(fingerprint in mediaFingerprints && !isDeepLocation(f.absolutePath)) return@forEach
                val opts=BitmapFactory.Options().apply { inJustDecodeBounds=true }
                // Bounds-only decode is safe: pixels are never allocated here.
                BitmapFactory.decodeFile(f.absolutePath,opts)
                val type=signature ?: if(ext.isNotBlank()) ext.uppercase(Locale.US) else "IMAGE"
                val category=classifyDeep(f)
                out["file:${f.absolutePath}"]=ImageItem("file:${f.absolutePath}",Uri.fromFile(f),f.name,f.length(),opts.outWidth.coerceAtLeast(0),opts.outHeight.coerceAtLeast(0),f.absolutePath,category,type,f)
            } catch (_: Throwable) { }
        }
    }

    private fun isDeepLocation(path:String):Boolean {
        val s=path.lowercase(Locale.US)
        return "/." in s || "thumb" in s || "cache" in s || "temp" in s || "tmp" in s || "/android/" in s
    }

    private fun classifyDeep(f:File):String {
        val s=f.absolutePath.lowercase(Locale.US)
        return when {
            "thumbnail" in s || "thumb" in s -> "Thumbnail"
            "cache" in s -> "Cache"
            "temp" in s || "/tmp" in s -> "Temporary"
            "/android/media/" in s -> "App media"
            f.name.startsWith(".") || s.split('/').any { it.startsWith(".") && it.length > 1 } || hasNomediaAncestor(f) -> "Hidden"
            else -> "File system"
        }
    }

    private fun hasNomediaAncestor(f: File): Boolean {
        val root = Environment.getExternalStorageDirectory().absolutePath
        var dir = f.parentFile
        while (dir != null && dir.absolutePath.startsWith(root)) {
            if (File(dir, ".nomedia").exists()) return true
            if (dir.absolutePath == root) break
            dir = dir.parentFile
        }
        return false
    }

    private fun setupFilters() {
        val filters=listOf("All","Deep only","Gallery","Hidden","Thumbnail","Cache","Temporary","App media","File system")
        filters.forEach { label ->
            val button=Button(this).apply {
                text=label.uppercase(Locale.US); textSize=10f; isAllCaps=false
                setTextColor(android.graphics.Color.parseColor("#F4F8FB"))
                backgroundTintList=android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#18232C"))
                setPadding(22,0,22,0)
                setOnClickListener { applyFilter(label) }
            }
            binding.filterBar.addView(button, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 44.dp()))
        }
    }

    private fun Int.dp():Int=(this*resources.displayMetrics.density).toInt()

    private fun applyFilter(filter:String) {
        activeFilter=filter
        val filtered=when(filter) {
            "All" -> allItems
            "Deep only" -> allItems.filter { it.category != "Gallery" }
            else -> allItems.filter { it.category == filter }
        }
        items.clear(); items.addAll(filtered); if(::adapter.isInitialized) adapter.notifyDataSetChanged()
        if(::binding.isInitialized) binding.resultsLabel.text="${filter.uppercase(Locale.US)} • ${items.size} RESULTS"
    }

    private fun detectImageSignature(f:File):String? {
        if(f.length()<4) return null
        val b=ByteArray(16); val n=FileInputStream(f).use { it.read(b) }; if(n<4)return null
        fun u(i:Int)=b[i].toInt() and 0xff
        return when {
            u(0)==0xFF && u(1)==0xD8 && u(2)==0xFF -> "JPEG"
            u(0)==0x89 && b.copyOfRange(1,4).toString(Charsets.ISO_8859_1)=="PNG" -> "PNG"
            b.copyOfRange(0,3).toString(Charsets.US_ASCII)=="GIF" -> "GIF"
            b.copyOfRange(0,4).toString(Charsets.US_ASCII)=="RIFF" && n>=12 && b.copyOfRange(8,12).toString(Charsets.US_ASCII)=="WEBP" -> "WEBP"
            u(0)==0x42 && u(1)==0x4D -> "BMP"
            n>=12 && b.copyOfRange(4,8).toString(Charsets.US_ASCII)=="ftyp" -> {
                val brand=b.copyOfRange(8,12).toString(Charsets.US_ASCII).lowercase(Locale.US)
                if(brand.contains("heic")||brand.contains("heif")||brand.contains("avif")||brand.contains("mif1")) brand.uppercase(Locale.US) else null
            }
            else -> null
        }
    }

    private fun humanSize(bytes:Long)=when { bytes>=1024L*1024L->String.format(Locale.US,"%.1f MB",bytes/(1024.0*1024)); bytes>=1024->String.format(Locale.US,"%.1f KB",bytes/1024.0); else->"$bytes B" }

    private fun safeDecodeFile(file:File,target:Int=220):Bitmap? {
        val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
        BitmapFactory.decodeFile(file.absolutePath,bounds)
        if(bounds.outWidth<=0||bounds.outHeight<=0)return null
        var sample=1
        while(bounds.outWidth/sample>target*2 || bounds.outHeight/sample>target*2) sample*=2
        return BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply { inSampleSize=sample; inPreferredConfig=Bitmap.Config.RGB_565 })
    }

    inner class ImageAdapter(private val data:List<ImageItem>):RecyclerView.Adapter<ImageAdapter.Holder>() {
        inner class Holder(val b:ItemImageBinding):RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent:ViewGroup,viewType:Int)=Holder(ItemImageBinding.inflate(LayoutInflater.from(parent.context),parent,false))
        override fun getItemCount()=data.size
        override fun onBindViewHolder(holder:Holder,position:Int) {
            val item=data[position]; holder.b.name.text=item.name
            holder.b.category.text=item.category.uppercase(Locale.US)
            holder.b.details.text="${item.detectedType} • ${item.width}×${item.height} • ${humanSize(item.size)}\n${item.location}"
            holder.b.thumb.setImageResource(android.R.drawable.ic_menu_gallery); holder.b.thumb.tag=item.key
            lifecycleScope.launch {
                val bitmap=withContext(Dispatchers.IO) { try { if(item.file!=null) safeDecodeFile(item.file) else if(Build.VERSION.SDK_INT>=29 && item.uri!=null) contentResolver.loadThumbnail(item.uri,Size(220,220),null) else null } catch(_:Throwable){null} }
                if(holder.b.thumb.tag==item.key && bitmap!=null) holder.b.thumb.setImageBitmap(bitmap)
            }
            holder.itemView.setOnClickListener {
                val meta="${item.category} • ${item.detectedType} • ${item.width}×${item.height} • ${humanSize(item.size)}\n${item.location}"
                startActivity(Intent(this@MainActivity,ViewerActivity::class.java).apply {
                    putExtra("name",item.name); putExtra("meta",meta)
                    item.file?.let { putExtra("path",it.absolutePath) }
                    if(item.file==null) item.uri?.let { putExtra("uri",it.toString()) }
                })
            }
        }
        override fun onViewRecycled(holder:Holder) { holder.b.thumb.tag=null; holder.b.thumb.setImageDrawable(null); super.onViewRecycled(holder) }
    }
}
