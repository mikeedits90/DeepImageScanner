package com.deepimagescanner.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deepimagescanner.app.databinding.ActivityMainBinding
import com.deepimagescanner.app.databinding.ItemImageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ImageItem(
    val id: Long,
    val name: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val relativePath: String?
)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val items = mutableListOf<ImageItem>()
    private lateinit var adapter: ImageAdapter

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) scan() else binding.status.text =
                "Image permission was not granted. Android limits apps to data you authorize."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ImageAdapter(items)
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter
        binding.scanButton.setOnClickListener { ensurePermissionAndScan() }
    }

    private fun ensurePermissionAndScan() {
        val permission = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            scan()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    private fun scan() {
        binding.status.text = "Scanning Android's accessible image library…"
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) {
                val result = mutableListOf<ImageItem>()
                val projection = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.WIDTH,
                    MediaStore.Images.Media.HEIGHT,
                    MediaStore.Images.Media.RELATIVE_PATH
                )
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection, null, null,
                    "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
                )?.use { c ->
                    val id = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val name = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val size = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                    val width = c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
                    val height = c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
                    val path = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
                    while (c.moveToNext()) {
                        result += ImageItem(
                            c.getLong(id), c.getString(name) ?: "(unnamed)",
                            c.getLong(size), c.getInt(width), c.getInt(height),
                            c.getString(path)
                        )
                    }
                }
                result
            }
            items.clear()
            items.addAll(found)
            adapter.notifyDataSetChanged()
            binding.count.text = "${items.size} images"
            binding.status.text =
                "Scan complete. These are images Android currently allows the app to access."
        }
    }

    inner class ImageAdapter(private val data: List<ImageItem>) :
        RecyclerView.Adapter<ImageAdapter.Holder>() {

        inner class Holder(val b: ItemImageBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
            Holder(ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount() = data.size

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val item = data[position]
            holder.b.name.text = item.name
            holder.b.details.text =
                "${item.width}×${item.height} • ${item.size / 1024} KB\n${item.relativePath ?: ""}"
            val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, item.id)
            holder.b.thumb.setImageURI(uri)
        }
    }
}
