package com.deepimagescanner.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.deepimagescanner.app.databinding.ActivityViewerBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

class ViewerActivity : AppCompatActivity() {
    private lateinit var b: ActivityViewerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b=ActivityViewerBinding.inflate(layoutInflater); setContentView(b.root); supportActionBar?.hide()
        b.backButton.setOnClickListener { finish() }
        val name=intent.getStringExtra("name") ?: "Image"
        val path=intent.getStringExtra("path")
        val uriText=intent.getStringExtra("uri")
        b.title.text=name
        b.meta.text=intent.getStringExtra("meta") ?: ""
        lifecycleScope.launch {
            val bmp=withContext(Dispatchers.IO) { runCatching { if(path!=null) decodeFile(File(path), 2560) else if(uriText!=null) decodeUri(Uri.parse(uriText),2560) else null }.getOrNull() }
            b.viewerProgress.visibility=View.GONE
            if(bmp!=null) b.fullImage.setImageBitmap(bmp) else b.meta.text="${b.meta.text}\nUnable to safely decode this image."
        }
    }
    private fun decodeFile(file:File,target:Int):Bitmap? {
        val o=BitmapFactory.Options().apply{inJustDecodeBounds=true}; BitmapFactory.decodeFile(file.absolutePath,o)
        if(o.outWidth<=0||o.outHeight<=0)return null
        var sample=1; while(max(o.outWidth,o.outHeight)/sample>target*2) sample*=2
        return BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply{inSampleSize=sample;inPreferredConfig=Bitmap.Config.ARGB_8888})
    }
    private fun decodeUri(uri:Uri,target:Int):Bitmap? {
        val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
        contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it,null,bounds)}
        if(bounds.outWidth<=0||bounds.outHeight<=0)return null
        var sample=1; while(max(bounds.outWidth,bounds.outHeight)/sample>target*2) sample*=2
        return contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply{inSampleSize=sample;inPreferredConfig=Bitmap.Config.ARGB_8888})}
    }
}
